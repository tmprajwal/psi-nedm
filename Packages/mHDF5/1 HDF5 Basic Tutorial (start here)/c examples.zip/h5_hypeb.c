/*************************************************************
 *  
 * This example shows how to write a subset of data (a slab) to
 * a dataset in an HDF5 file.
 *
 *************************************************************/
 
#include "hdf5.h"

#define FILE        "hype.h5"
#define DATASETNAME "IntArray" 
#define RANK  2

#define DIM0     8                 /* size of dataset */       
#define DIM1     10 

int
main (void)
{
    int         rdata[DIM0][DIM1];          /* buffer for read */
 
    hid_t       file_id, dataset_id;        /* handles */
    hid_t       dataspace_id; 

    herr_t      status;                             
   
    hsize_t     count[2];              /* size of subset in the file */
    hsize_t     offset[2];             /* subset offset in the file */
    hsize_t     stride[2];
    hsize_t     block[2];
    int         i, j;


    /*************************************************************
     * Open the file and dataset and read a selection
     *************************************************************/

    file_id = H5Fopen (FILE, H5F_ACC_RDWR, H5P_DEFAULT);
    dataset_id = H5Dopen (file_id, DATASETNAME, H5P_DEFAULT);


    /*************************************************************
     * Read data using block and stride in selection  
     *************************************************************/
    status = H5Dread (dataset_id, H5T_NATIVE_INT, H5S_ALL, H5S_ALL,
                       H5P_DEFAULT, rdata);

    printf ("\nData In File :\n");
    for (i = 0; i<DIM0; i++){ 
       for (j = 0; j<DIM1; j++) 
           printf (" %i", rdata[i][j]);
       printf ("\n");
    } 

    offset[0] = 1;
    offset[1] = 1; 

    count[0]  = 2;  
    count[1]  = 2;

    stride[0] = 4;
    stride[1] = 4;

    block [0] = 2;
    block [1] = 2;


    for (i = 0; i<DIM0; i++)
       for (j = 0; j<DIM1; j++) 
           rdata[i][j]= 0;

    dataspace_id = H5Dget_space (dataset_id);
    status = H5Sselect_hyperslab (dataspace_id, H5S_SELECT_SET, offset,
                                  stride, count, block); 

    status = H5Dread (dataset_id, H5T_NATIVE_INT, H5S_ALL, dataspace_id,  
                      H5P_DEFAULT, rdata); 
  
    printf ("\nSelected Data Read From File:\n");
    for (i = 0; i<DIM0; i++){ 
       for (j = 0; j<DIM1; j++) 
           printf (" %i", rdata[i][j]);
       printf ("\n");
    }
    

    status = H5Sclose (dataspace_id);
    status = H5Dclose (dataset_id);
    status = H5Fclose (file_id);
 
}     

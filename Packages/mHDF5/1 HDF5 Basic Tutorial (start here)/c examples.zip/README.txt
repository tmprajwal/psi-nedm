These "c" examples appear in the HDF5 tutorial:

http://www.hdfgroup.org/HDF5/Tutor/introductory.html. 



These examples are implemented as Mathematica examples in the parent directory.



Prepared by Scot Martin, 10 July 2011. Rechecked on 12 July 2016.